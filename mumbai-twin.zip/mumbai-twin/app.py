"""
Mumbai Digital Twin — SDG 11 Backend Server
============================================
Run:  pip install flask flask-cors numpy
      python app.py
API runs at: http://localhost:5000
"""

from flask import Flask, jsonify, request
from flask_cors import CORS
import numpy as np
import math
import time
import random
import threading

app = Flask(__name__)
CORS(app)  # Allow frontend to call this API

# ═══════════════════════════════════════════════════════════
#  MUMBAI ZONE DEFINITIONS
#  Each zone has: id, name, lat/lng bounds, base values
# ═══════════════════════════════════════════════════════════
ZONES = [
    {
        "id": "south_mumbai",
        "name": "South Mumbai",
        "bounds": [[18.93, 72.82], [19.01, 72.88]],
        "center": [18.97, 72.85],
        "base": {"ndvi": 18, "lst": 82, "flood_risk": 55, "buildup": 92}
    },
    {
        "id": "dharavi",
        "name": "Dharavi",
        "bounds": [[19.01, 72.84], [19.07, 72.89]],
        "center": [19.04, 72.865],
        "base": {"ndvi": 12, "lst": 88, "flood_risk": 91, "buildup": 96}
    },
    {
        "id": "andheri",
        "name": "Andheri",
        "bounds": [[19.07, 72.84], [19.14, 72.93]],
        "center": [19.105, 72.885],
        "base": {"ndvi": 28, "lst": 75, "flood_risk": 62, "buildup": 84}
    },
    {
        "id": "aarey",
        "name": "Aarey Colony",
        "bounds": [[19.04, 72.91], [19.09, 72.97]],
        "center": [19.065, 72.94],
        "base": {"ndvi": 78, "lst": 41, "flood_risk": 22, "buildup": 18}
    },
    {
        "id": "borivali",
        "name": "Borivali",
        "bounds": [[19.16, 72.84], [19.22, 72.92]],
        "center": [19.19, 72.88],
        "base": {"ndvi": 55, "lst": 58, "flood_risk": 30, "buildup": 68}
    },
    {
        "id": "sanjay_gandhi",
        "name": "Sanjay Gandhi NP",
        "bounds": [[19.18, 72.78], [19.28, 72.92]],
        "center": [19.23, 72.85],
        "base": {"ndvi": 91, "lst": 32, "flood_risk": 15, "buildup": 5}
    },
    {
        "id": "thane",
        "name": "Thane",
        "bounds": [[19.19, 72.96], [19.26, 73.04]],
        "center": [19.225, 73.00],
        "base": {"ndvi": 34, "lst": 70, "flood_risk": 72, "buildup": 78}
    },
    {
        "id": "kurla",
        "name": "Kurla",
        "bounds": [[19.02, 72.90], [19.06, 72.96]],
        "center": [19.04, 72.93],
        "base": {"ndvi": 15, "lst": 85, "flood_risk": 85, "buildup": 91}
    },
    {
        "id": "mira_road",
        "name": "Mira Road",
        "bounds": [[19.22, 72.84], [19.30, 72.94]],
        "center": [19.26, 72.89],
        "base": {"ndvi": 30, "lst": 72, "flood_risk": 48, "buildup": 74}
    },
    {
        "id": "vikhroli",
        "name": "Vikhroli",
        "bounds": [[19.09, 72.87], [19.15, 72.95]],
        "center": [19.12, 72.91],
        "base": {"ndvi": 22, "lst": 79, "flood_risk": 75, "buildup": 83}
    },
]

# ═══════════════════════════════════════════════════════════
#  LIVE STATE — This is the "current" data for each zone
#  It changes slightly over time to simulate real telemetry
# ═══════════════════════════════════════════════════════════
live_state = {}
active_scenario = None
scenario_start_time = None

def init_live_state():
    """Initialize live state from base values with small random offsets"""
    global live_state
    for zone in ZONES:
        live_state[zone["id"]] = {
            "ndvi":       zone["base"]["ndvi"],
            "lst":        zone["base"]["lst"],
            "flood_risk": zone["base"]["flood_risk"],
            "buildup":    zone["base"]["buildup"],
        }

init_live_state()

# ═══════════════════════════════════════════════════════════
#  BACKGROUND TICKER — Updates data every 5 seconds
#  to simulate real satellite feed
# ═══════════════════════════════════════════════════════════
def live_ticker():
    """Runs in background. Adds small realistic fluctuations to simulate live data."""
    while True:
        time.sleep(5)
        for zone in ZONES:
            zid = zone["id"]
            s = live_state[zid]
            # Small random drift ±1 on each metric
            s["ndvi"]       = float(np.clip(s["ndvi"]       + random.uniform(-0.8, 0.8), 0, 100))
            s["lst"]        = float(np.clip(s["lst"]        + random.uniform(-0.5, 0.5), 20, 100))
            s["flood_risk"] = float(np.clip(s["flood_risk"] + random.uniform(-0.5, 0.5), 0, 100))
            s["buildup"]    = float(np.clip(s["buildup"]    + random.uniform(-0.2, 0.2), 0, 100))

ticker_thread = threading.Thread(target=live_ticker, daemon=True)
ticker_thread.start()

# ═══════════════════════════════════════════════════════════
#  SCENARIO DEFINITIONS
#  Each scenario changes the live state for all zones
# ═══════════════════════════════════════════════════════════
SCENARIOS = {
    "baseline": {
        "label": "Baseline",
        "modifiers": {}  # No changes — just reset to base
    },
    "green": {
        "label": "+10% Green Cover",
        "modifiers": {
            # zone_id: {metric: delta}
            "south_mumbai": {"ndvi": +10, "lst": -6, "flood_risk": -8},
            "dharavi":      {"ndvi": +10, "lst": -5, "flood_risk": -6},
            "andheri":      {"ndvi": +12, "lst": -7, "flood_risk": -10},
            "kurla":        {"ndvi": +10, "lst": -5, "flood_risk": -8},
            "mira_road":    {"ndvi": +10, "lst": -5, "flood_risk": -5},
            "vikhroli":     {"ndvi": +10, "lst": -6, "flood_risk": -7},
            "borivali":     {"ndvi": +8,  "lst": -4, "flood_risk": -4},
            "thane":        {"ndvi": +8,  "lst": -4, "flood_risk": -5},
        }
    },
    "flood": {
        "label": "Flash Flood Event",
        "modifiers": {
            "dharavi":      {"flood_risk": +25, "lst": -8},
            "kurla":        {"flood_risk": +22, "lst": -7},
            "vikhroli":     {"flood_risk": +20, "lst": -6},
            "south_mumbai": {"flood_risk": +18, "lst": -5},
            "andheri":      {"flood_risk": +15, "lst": -4},
            "thane":        {"flood_risk": +18, "lst": -5},
        }
    },
    "heat": {
        "label": "Extreme Heatwave +4°C",
        "modifiers": {
            "south_mumbai": {"lst": +14, "ndvi": -5, "flood_risk": -10},
            "dharavi":      {"lst": +16, "ndvi": -6, "flood_risk": -12},
            "andheri":      {"lst": +13, "ndvi": -5, "flood_risk": -10},
            "kurla":        {"lst": +15, "ndvi": -5, "flood_risk": -11},
            "mira_road":    {"lst": +12, "ndvi": -4, "flood_risk": -8},
            "vikhroli":     {"lst": +13, "ndvi": -4, "flood_risk": -9},
            "borivali":     {"lst": +10, "ndvi": -3, "flood_risk": -7},
        }
    },
    "drought": {
        "label": "60-Day Drought",
        "modifiers": {
            "south_mumbai": {"ndvi": -12, "lst": +10, "flood_risk": -25},
            "dharavi":      {"ndvi": -10, "lst": +12, "flood_risk": -28},
            "andheri":      {"ndvi": -14, "lst": +11, "flood_risk": -22},
            "aarey":        {"ndvi": -18, "lst": +8,  "flood_risk": -15},
            "kurla":        {"ndvi": -10, "lst": +10, "flood_risk": -20},
            "thane":        {"ndvi": -12, "lst": +10, "flood_risk": -20},
        }
    },
    "solar": {
        "label": "Solar City Initiative",
        "modifiers": {
            "south_mumbai": {"lst": -8,  "ndvi": +4,  "buildup": -3},
            "dharavi":      {"lst": -7,  "ndvi": +5,  "buildup": -4},
            "andheri":      {"lst": -10, "ndvi": +6,  "buildup": -5},
            "kurla":        {"lst": -8,  "ndvi": +4,  "buildup": -4},
            "mira_road":    {"lst": -7,  "ndvi": +4,  "flood_risk": -5},
            "borivali":     {"lst": -6,  "ndvi": +5,  "buildup": -3},
        }
    }
}

# ═══════════════════════════════════════════════════════════
#  HELPER: Compute zone SDG score
# ═══════════════════════════════════════════════════════════
def zone_sdg_score(z):
    return round(
        0.35 * (100 - z["flood_risk"]) +
        0.30 * z["ndvi"] +
        0.25 * (100 - z["lst"]) +
        0.10 * (100 - z["buildup"])
    )

def risk_level(score):
    if score >= 60: return "LOW"
    if score >= 40: return "MODERATE"
    return "HIGH"

def color_for_ndvi(v):
    if v >= 60: return "#00ff88"
    if v >= 40: return "#00ddb4"
    if v >= 20: return "#ffcc00"
    return "#ff6d00"

def color_for_lst(v):
    if v >= 80: return "#ff1744"
    if v >= 65: return "#ff3d5a"
    if v >= 50: return "#ffcc00"
    return "#00ddb4"

def color_for_flood(v):
    if v >= 75: return "#2979ff"
    if v >= 50: return "#448aff"
    if v >= 25: return "#82b1ff"
    return "#e3f2fd"

def color_for_buildup(v):
    if v >= 80: return "#aa00ff"
    if v >= 60: return "#d500f9"
    if v >= 40: return "#ea80fc"
    return "#f3e5f5"

# ═══════════════════════════════════════════════════════════
#  API ROUTES
# ═══════════════════════════════════════════════════════════

@app.route("/api/health", methods=["GET"])
def health():
    """Simple health check — confirms backend is running"""
    return jsonify({"status": "online", "message": "Mumbai Digital Twin API v1.0"})


@app.route("/api/zones", methods=["GET"])
def get_zones():
    """
    Returns live data for ALL zones.
    Frontend calls this every 5 seconds to update the map.
    Response includes: bounds, live metrics, SDG score, color
    """
    layer = request.args.get("layer", "flood_risk")  # which layer to show colors for
    result = []

    for zone in ZONES:
        zid = zone["id"]
        s = live_state[zid]
        score = zone_sdg_score(s)

        # Pick fill color based on requested layer
        if layer == "ndvi":
            fill_color = color_for_ndvi(s["ndvi"])
            value = round(s["ndvi"])
            unit = "%"
        elif layer == "lst":
            fill_color = color_for_lst(s["lst"])
            value = round(s["lst"])
            unit = "%"
        elif layer == "buildup":
            fill_color = color_for_buildup(s["buildup"])
            value = round(s["buildup"])
            unit = "%"
        else:  # flood_risk (default)
            fill_color = color_for_flood(s["flood_risk"])
            value = round(s["flood_risk"])
            unit = "%"

        result.append({
            "id":         zid,
            "name":       zone["name"],
            "bounds":     zone["bounds"],
            "center":     zone["center"],
            "metrics": {
                "ndvi":       round(s["ndvi"], 1),
                "lst":        round(s["lst"], 1),
                "flood_risk": round(s["flood_risk"], 1),
                "buildup":    round(s["buildup"], 1),
            },
            "sdg_score":  score,
            "risk_level": risk_level(score),
            "fill_color": fill_color,
            "fill_opacity": 0.55,
            "display_value": f"{value}{unit}",
            "layer": layer
        })

    return jsonify({
        "timestamp": time.time(),
        "scenario":  active_scenario or "baseline",
        "layer":     layer,
        "zones":     result
    })


@app.route("/api/summary", methods=["GET"])
def get_summary():
    """
    Returns city-wide averages — used for header stats and SDG score ring.
    """
    all_ndvi  = [live_state[z["id"]]["ndvi"]       for z in ZONES]
    all_lst   = [live_state[z["id"]]["lst"]         for z in ZONES]
    all_flood = [live_state[z["id"]]["flood_risk"]  for z in ZONES]
    all_bup   = [live_state[z["id"]]["buildup"]     for z in ZONES]

    avg = {
        "ndvi":       round(np.mean(all_ndvi), 1),
        "lst":        round(np.mean(all_lst), 1),
        "flood_risk": round(np.mean(all_flood), 1),
        "buildup":    round(np.mean(all_bup), 1),
    }
    city_score = round(
        0.35*(100-avg["flood_risk"]) +
        0.30*avg["ndvi"] +
        0.25*(100-avg["lst"]) +
        0.10*(100-avg["buildup"])
    )

    return jsonify({
        "timestamp":  time.time(),
        "scenario":   active_scenario or "baseline",
        "city_score": city_score,
        "averages":   avg,
        "zone_count": len(ZONES),
        "high_risk_zones": sum(1 for z in ZONES if zone_sdg_score(live_state[z["id"]]) < 40),
        "moderate_risk_zones": sum(1 for z in ZONES if 40 <= zone_sdg_score(live_state[z["id"]]) < 60),
        "low_risk_zones": sum(1 for z in ZONES if zone_sdg_score(live_state[z["id"]]) >= 60),
    })


@app.route("/api/scenario", methods=["POST"])
def set_scenario():
    """
    Activates a what-if scenario.
    POST body: { "scenario": "flood" }
    This updates live_state for all zones based on scenario modifiers.
    """
    global active_scenario
    body = request.get_json()
    name = body.get("scenario", "baseline")

    if name not in SCENARIOS:
        return jsonify({"error": f"Unknown scenario: {name}"}), 400

    # Reset to base first
    init_live_state()

    # Apply modifiers
    if name != "baseline":
        mods = SCENARIOS[name]["modifiers"]
        for zone in ZONES:
            zid = zone["id"]
            if zid in mods:
                for metric, delta in mods[zid].items():
                    base_val = zone["base"][metric]
                    live_state[zid][metric] = float(np.clip(base_val + delta, 0, 100))

    active_scenario = name
    summary_data = get_summary().get_json()

    return jsonify({
        "status":   "ok",
        "scenario": name,
        "label":    SCENARIOS[name]["label"],
        "city_score": summary_data["city_score"],
        "averages": summary_data["averages"]
    })


@app.route("/api/zone/<zone_id>", methods=["GET"])
def get_zone(zone_id):
    """
    Returns detailed data for a single zone.
    Called when user clicks on a zone on the map.
    """
    zone = next((z for z in ZONES if z["id"] == zone_id), None)
    if not zone:
        return jsonify({"error": "Zone not found"}), 404

    s = live_state[zone_id]
    score = zone_sdg_score(s)

    return jsonify({
        "id":       zone_id,
        "name":     zone["name"],
        "center":   zone["center"],
        "metrics":  {k: round(v, 1) for k, v in s.items()},
        "sdg_score": score,
        "risk_level": risk_level(score),
        "insight": generate_insight(zone["name"], s, score)
    })


@app.route("/api/history", methods=["GET"])
def get_history():
    """
    Returns simulated historical trend data for charts.
    In a real system this would come from a database.
    """
    months = ["Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec","Jan","Feb"]
    # Simulate historical scores with realistic monsoon seasonality
    base_scores = [41,39,36,38,55,60,58,52,46,43,41,42]
    flood_history = [22,28,38,72,91,88,68,42,28,18,15,20]

    return jsonify({
        "months": months,
        "sdg_scores": base_scores,
        "flood_risk_monthly": flood_history,
        "ndvi_monthly": [32,31,30,34,42,48,45,40,36,33,32,34],
        "lst_monthly":  [74,76,80,77,65,60,62,68,72,74,72,72],
    })


@app.route("/api/ai-forecast", methods=["GET"])
def ai_forecast():
    """
    Returns AI-generated risk forecast based on current state.
    In production this would use a real ML model.
    """
    s_name = active_scenario or "baseline"
    forecasts = {
        "baseline": {
            "flood_prob": 78,
            "flood_label": "High — monsoon onset approaching",
            "heat_label": "High across 14 urban zones",
            "recommendation": "Deploy 12 green buffer corridors in Andheri–Borivali belt"
        },
        "green": {
            "flood_prob": 62,
            "flood_label": "Moderate — vegetation buffers helping",
            "heat_label": "Moderate — cooling corridors active",
            "recommendation": "Continue Phase 2 planting for full 20% coverage benefit"
        },
        "flood": {
            "flood_prob": 95,
            "flood_label": "CRITICAL — active inundation event",
            "heat_label": "Low — cloud cover reducing solar gain",
            "recommendation": "EVACUATE Dharavi & coastal zones immediately"
        },
        "heat": {
            "flood_prob": 12,
            "flood_label": "Low — dry conditions prevail",
            "heat_label": "EXTREME across all 10 zones",
            "recommendation": "Open 18 cooling centers; restrict outdoor activity 11AM–4PM"
        },
        "drought": {
            "flood_prob": 8,
            "flood_label": "Very Low — severe dry spell active",
            "heat_label": "High — moisture deficit worsening",
            "recommendation": "Activate water rationing Protocol 3; emergency reservoir checks"
        },
        "solar": {
            "flood_prob": 60,
            "flood_label": "Moderate — permeable surfaces improving absorption",
            "heat_label": "Moderate — reflective rooftops reducing UHI",
            "recommendation": "Phase 2 solar deployment: target Dharavi & Kurla next"
        }
    }
    return jsonify(forecasts.get(s_name, forecasts["baseline"]))


# ═══════════════════════════════════════════════════════════
#  HELPER: Auto-generate zone insight text
# ═══════════════════════════════════════════════════════════
def generate_insight(name, s, score):
    issues = []
    if s["flood_risk"] > 70: issues.append("critical flood risk")
    if s["lst"] > 80:        issues.append("extreme heat island")
    if s["ndvi"] < 20:       issues.append("severe vegetation deficit")
    if s["buildup"] > 88:    issues.append("maximum urban density")
    if not issues:
        return f"{name} is performing well with SDG score {score}/100."
    return f"{name} faces {', '.join(issues)}. SDG score: {score}/100. Immediate intervention recommended."


# ═══════════════════════════════════════════════════════════
#  RUN
# ═══════════════════════════════════════════════════════════
if __name__ == "__main__":
    print("=" * 55)
    print("  Mumbai Digital Twin — Backend API")
    print("  Running at: http://localhost:5000")
    print("  Endpoints:")
    print("    GET  /api/health")
    print("    GET  /api/zones?layer=flood_risk")
    print("    GET  /api/summary")
    print("    GET  /api/history")
    print("    GET  /api/ai-forecast")
    print("    POST /api/scenario  {scenario: 'flood'}")
    print("    GET  /api/zone/<id>")
    print("=" * 55)
    app.run(debug=True, port=5000, threaded=True)